package com.example.coding;

public class PersonTest
{
    public static void main(String[] args)
    {
        Person person = new Person();
        person.printDetailsToConsole();
    }
}
