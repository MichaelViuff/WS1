package com.example.coding;

public class Person
{
    private String name;
    private int age;
    private double weight;

    //TODO: Generate Constructor
    //TODO: Generate getters/setters
}
