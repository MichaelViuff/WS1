package com.example.library.model;
public enum ReservationStatus { REQUESTED, READY_FOR_PICKUP, CANCELLED }
