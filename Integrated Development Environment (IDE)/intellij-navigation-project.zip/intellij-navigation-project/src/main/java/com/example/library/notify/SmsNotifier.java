package com.example.library.notify;

public class SmsNotifier implements Notifier {
    @Override public void send(String userId, String message) {
        // imagine sms here
    }
}
