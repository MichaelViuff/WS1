package com.example.library.model;

public record LibraryUser(String id, String name, boolean child) { }
