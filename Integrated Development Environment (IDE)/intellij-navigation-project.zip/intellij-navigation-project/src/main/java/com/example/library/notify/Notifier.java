package com.example.library.notify;

public interface Notifier {
    void send(String userId, String message);
}
