package com.example.library.model;
public record Author(String name) { }
