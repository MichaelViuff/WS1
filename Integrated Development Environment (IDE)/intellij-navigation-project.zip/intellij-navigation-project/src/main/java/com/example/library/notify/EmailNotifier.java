package com.example.library.notify;

public class EmailNotifier implements Notifier {
    @Override public void send(String userId, String message) {
        // imagine email here
    }
}
